<?php
namespace aki\telegram\base;

use yii\base\Component;

/**
 * 
 */
class Type extends Component
{
    
}