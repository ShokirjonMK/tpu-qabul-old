<?php
namespace aki\telegram\types;


use aki\telegram\base\Type;

/**
 * @author Akbar Joudi <akbar.joody@gmail.com>
 * 
 */
class Entitie extends Type
{
    public $offset;

    public $length;

    public $type;

    public $url;
}